package tramitesacademicos;

public class Profesor {

	
	private String direccion;
	private String departamento;
}
