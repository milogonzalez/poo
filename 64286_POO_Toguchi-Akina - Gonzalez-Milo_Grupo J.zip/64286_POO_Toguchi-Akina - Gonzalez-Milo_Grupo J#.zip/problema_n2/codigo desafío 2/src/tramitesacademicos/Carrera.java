package tramitesacademicos;

public class Carrera {
	
	private String carrera;
	private String sede;
	
	
	
	public Carrera(String carrera, String sede) {
		super();
		this.carrera = carrera;
		this.sede = sede;
	}

}
