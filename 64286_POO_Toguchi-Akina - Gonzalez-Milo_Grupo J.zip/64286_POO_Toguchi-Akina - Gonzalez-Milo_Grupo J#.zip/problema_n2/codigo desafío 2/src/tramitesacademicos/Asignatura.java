package tramitesacademicos;

public class Asignatura {
	
	private String nombre;
	private int cantDeHoras;
	private String cuatrimestre;
	private String tipo;
	

}
